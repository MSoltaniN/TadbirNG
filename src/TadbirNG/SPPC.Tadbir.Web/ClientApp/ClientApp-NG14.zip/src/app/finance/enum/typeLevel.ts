
export enum TypeLevel {
  AllAccounts = 0,
  LeafAccounts = 1,
  NonLeafAccounts = 2
}

