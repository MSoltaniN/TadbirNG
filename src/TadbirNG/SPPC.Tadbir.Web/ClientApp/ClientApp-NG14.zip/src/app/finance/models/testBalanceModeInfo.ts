
export class TestBalanceModeInfo {
  id: number;
  name: string;
  level: number;
  isDetail: boolean;
}
