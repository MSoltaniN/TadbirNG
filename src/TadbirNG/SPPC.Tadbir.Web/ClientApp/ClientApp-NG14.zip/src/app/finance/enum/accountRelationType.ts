﻿
export enum AccountRelationsType {
    Account = 1,
    DetailAccount = 2,
    CostCenter = 3,
    Project = 4
}

