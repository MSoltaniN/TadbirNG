import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-widget-setting',
  templateUrl: './widget-setting.component.html',
  styleUrls: ['./widget-setting.component.css']
})
export class WidgetSettingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
