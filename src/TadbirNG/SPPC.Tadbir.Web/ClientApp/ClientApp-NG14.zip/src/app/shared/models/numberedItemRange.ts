

export interface NumberedItemRange {
  viewId: number;
  firstNo: number;
  lastNo: number;
}
