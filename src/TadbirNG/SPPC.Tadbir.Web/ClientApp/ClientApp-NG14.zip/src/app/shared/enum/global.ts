export enum ReloadStatusType {
  None = 0,
  AfterDelete = 1,
  AfterFilter = 2,
  AfterSort = 3,
  AfterEdit = 4,
  AfterInsert = 5,
  AfterAdvanceFilter = 6
}
