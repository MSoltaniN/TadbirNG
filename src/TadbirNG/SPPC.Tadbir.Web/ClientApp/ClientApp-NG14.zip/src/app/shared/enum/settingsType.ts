
export enum SettingsType {
  RelationsConfig = "RelationsConfig",
  DateRangeConfig = "DateRangeConfig",
  NumberDisplayConfig = "NumberDisplayConfig",
  ViewTreeConfig = "ViewTreeConfig",
  EntityRowAccessConfig = "EntityRowAccessConfig",
  FinanceReportConfig = "FinanceReportConfig"
}

