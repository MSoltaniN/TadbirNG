export interface QuickSearchColumnConfig {
  name: string;
  title: string;
  displayIndex: number;
  isDisplayed: boolean;
  isSearched: boolean;
}
