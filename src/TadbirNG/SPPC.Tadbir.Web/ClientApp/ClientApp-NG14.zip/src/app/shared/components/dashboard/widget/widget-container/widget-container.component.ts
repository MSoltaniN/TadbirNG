import { Component, OnInit } from "@angular/core";

@Component({
  selector: "widget-container",
  templateUrl: "./widget-container.component.html",
  styleUrls: ["./widget-container.component.css"],
})
export class WidgetContainerComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
