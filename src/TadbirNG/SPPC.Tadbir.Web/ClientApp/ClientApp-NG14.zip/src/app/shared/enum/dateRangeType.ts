
export enum DateRangeType {
  FiscalStartToCurrent = 'FiscalStartToCurrent',
  FiscalStartToFiscalEnd = 'FiscalStartToFiscalEnd',
  CurrentToCurrent = 'CurrentToCurrent'
}

