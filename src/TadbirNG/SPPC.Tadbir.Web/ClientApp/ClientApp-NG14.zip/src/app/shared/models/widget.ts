export class Widget {
  id: number;
  name: string;
  title: string;
  selected?: boolean;
}
