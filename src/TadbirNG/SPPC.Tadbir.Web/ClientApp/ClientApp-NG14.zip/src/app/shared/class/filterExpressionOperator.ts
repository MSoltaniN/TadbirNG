﻿
export class FilterExpressionOperator {
    constructor() {}
    public static None: string = "";
    public static And: string = " && ";
    public static Or: string = " || ";
}