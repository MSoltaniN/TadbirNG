export class QuickReportViewSetting {
  public hideHorizontalLine: boolean;
  public hideVerticalLine: boolean;
}
