
export enum SettingKey {
  DateRangeConfig = 2,
  NumberDisplayConfig = 3,
  FinanceReportConfig = 9,
  SystemConfig = 8
}

