﻿export interface IEntity {

}