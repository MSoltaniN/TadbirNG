﻿//*** this class add for OrderBy for gridview */

export class GridOrderBy {

    constructor(private fieldName: string, private direction: string) {
    }
}