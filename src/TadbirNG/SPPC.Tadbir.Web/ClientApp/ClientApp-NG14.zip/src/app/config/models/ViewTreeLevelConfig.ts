

export interface ViewTreeLevelConfig {
  no: number;
  name: string;
  codeLength: number;
  isEnabled: boolean;
  isUsed: boolean;
}
