

export interface NumberConfig{
  decimalPrecision: number;
  maxPrecision: number;
  useSeparator: boolean;
  separatorMode: string;
  separatorSymbol: string;
}
