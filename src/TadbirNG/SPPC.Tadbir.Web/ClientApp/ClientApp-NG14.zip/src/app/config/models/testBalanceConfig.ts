export interface TestBalanceConfig {
  addOpeningVoucherToInitBalance: boolean;  
}
