import {Injector} from "@angular/core";

export class ServiceLocator {
    static injector: Injector;
}
